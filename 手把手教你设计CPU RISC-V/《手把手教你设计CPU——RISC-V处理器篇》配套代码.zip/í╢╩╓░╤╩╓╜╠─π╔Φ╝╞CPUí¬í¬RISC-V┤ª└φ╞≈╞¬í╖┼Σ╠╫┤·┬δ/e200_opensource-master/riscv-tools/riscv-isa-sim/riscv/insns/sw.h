MMU.store_uint32(RS1 + insn.s_imm(), RS2);
